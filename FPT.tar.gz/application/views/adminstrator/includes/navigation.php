  <!-- Navbar -->
  <nav class="main-header navbar fixed-top  navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>
    </ul>

    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item dropdown">
        <a class="nav-link" href="<?php echo base_url('Home/logout'); ?>">
          <i class="fa fa-sign-out "></i> Logout
        </a>
      </li>

    </ul>
  </nav>
  <!-- /.navbar -->