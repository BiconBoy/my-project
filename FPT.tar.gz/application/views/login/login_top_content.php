<!doctype html>
<!--[if gt IE 8]><!-->
<html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>SMCoSE FPT-TP system</title>
 <link  rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/admin/images/logosua.gif">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

    <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/login/css/bootstrap.min.css">
    
    <!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/login/css/font-awesome.min.css">
    
    <!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/login/css/style.css">

    <link href="<?php echo base_url(); ?>assets/login/plugins/sweetalert/lib/sweet-alert.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>assets/login/plugins/toastr/toastr.min.css" rel="stylesheet" />

  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,700,600,400'
        rel='stylesheet' type='text/css'>
    <style>
     div#preloader {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 99999;
  width: 100%;
  height: 100%;
  overflow: visible;
  background: #fff url("<? echo base_url('assets/loading/810.gif'); ?>") no-repeat center center;
}
</style>
</head>
    <body>
  
    <!-- Main Wrapper -->
        <div class="main-wrapper login-body">
            <div class="login-wrapper">
              <div class="container">
                  <div class="loginbox">