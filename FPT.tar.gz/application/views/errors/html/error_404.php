
<?php $page_error = "OK"; header("location: /",$page_error); ?>